

import React, { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import { createRoot } from 'react-dom/client';
import { GoogleGenAI, Type, Chat } from "@google/genai";

// --- Constants ---
const MODEL_VERSIONS = [
  { id: 'gemini-2.5-flash', name: 'Gemini 2.5 Flash (Stable)' },
  // Future models can be added here, e.g., { id: 'gemini-2.5-flash-preview', name: 'Gemini 2.5 Flash (Preview)' }
];

const DEFECT_TYPES = [
    'Cracks in Plaster', 'Peeling Paint', 'Efflorescence', 'Dampness / Moisture Stains',
    'Hollow Plaster', 'Bulging Surface', 'Tile Cracking', 'Tile Debonding',
    'Uneven Tile Alignment', 'Grout Cracking', 'Water Seepage through Tiles',
    'Ceiling Cracks', 'Sagging Ceiling', 'Ceiling Water Stains', 'Ceiling Paint Peeling',
    'Mold / Mildew Growth', 'No Defect / Good Condition'
];

const PRIORITIES = ['Low', 'Medium', 'High'];
const STATUSES = ['Open', 'In Progress', 'Resolved'];


// --- Helper Functions ---

/**
 * Converts a File object to a base64 encoded string.
 * @param {File} file The file to convert.
 * @returns {Promise<string>} A promise that resolves with the base64 string.
 */
const fileToGenerativePart = async (file: File) => {
  const base64EncodedDataPromise = new Promise<string>((resolve) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.readAsDataURL(file);
  });
  return {
    inlineData: { data: await base64EncodedDataPromise, mimeType: file.type },
  };
};

// --- Main Application Component ---

const App = () => {
  // --- State Management ---
  const [apiKey, setApiKey] = useState<string>(() => localStorage.getItem('userApiKey') || '');
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [selectedModel, setSelectedModel] = useState<string>(MODEL_VERSIONS[0].id);


  // State for historical logs and filtering
  const [currentView, setCurrentView] = useState<'analyzer' | 'projects' | 'logs' | 'reports' | 'settings' | 'chat'>('analyzer');
  const [loggedDefects, setLoggedDefects] = useState<any[]>(() => {
    try {
        const savedLogs = localStorage.getItem('defectLogs');
        return savedLogs ? JSON.parse(savedLogs) : [];
    } catch (error) {
        console.error("Failed to parse logs from localStorage", error);
        return [];
    }
  });
  const [filters, setFilters] = useState({
    projectName: '',
    defectType: '',
    severity: '',
    responsibleParty: '',
    priority: '',
    status: '',
  });
  const [selectedLog, setSelectedLog] = useState<any | null>(null);
  const [isLogging, setIsLogging] = useState<boolean>(false); // To show the log details form
  
  // State for reports
  const [selectedProjectForReport, setSelectedProjectForReport] = useState<string | null>(null);

  // State for feedback loop
  const [userCorrection, setUserCorrection] = useState<string | null>(null);
  const [feedbackSubmitted, setFeedbackSubmitted] = useState<boolean>(false);
  const [feedbackLogs, setFeedbackLogs] = useState<any[]>(() => {
    try {
        const savedFeedback = localStorage.getItem('defectFeedback');
        return savedFeedback ? JSON.parse(savedFeedback) : [];
    } catch (error) {
        console.error("Failed to parse feedback from localStorage", error);
        return [];
    }
  });

  // State for Chatbot
  const [chatInstance, setChatInstance] = useState<Chat | null>(null);
  const [chatMessages, setChatMessages] = useState<Array<{role: 'user' | 'model', text: string}>>([]);
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);
  const [chatInput, setChatInput] = useState<string>('');


  // Persist logs to localStorage whenever they change
  useEffect(() => {
    try {
        localStorage.setItem('defectLogs', JSON.stringify(loggedDefects));
    } catch (error) {
        console.error("Failed to save logs to localStorage", error);
    }
  }, [loggedDefects]);

  // Persist feedback to localStorage whenever it changes
  useEffect(() => {
    try {
        localStorage.setItem('defectFeedback', JSON.stringify(feedbackLogs));
    } catch (error) {
        console.error("Failed to save feedback to localStorage", error);
    }
  }, [feedbackLogs]);


  /**
   * Handles the file input change event.
   * Sets the image file and preview in the state.
   */
  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
      setAnalysisResult(null);
      setError(null);
      setFeedbackSubmitted(false);
      setUserCorrection(null);
    }
  };

  /**
   * Resets the application to its initial state.
   */
  const resetState = () => {
      setImageFile(null);
      setImagePreview(null);
      setAnalysisResult(null);
      setError(null);
      setIsLoading(false);
      setFeedbackSubmitted(false);
      setUserCorrection(null);
      setIsLogging(false);
  }

  /**
   * Handles saving the defect log with project management details.
   */
  const handleSaveLog = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const logDetails = {
        projectName: formData.get('projectName') as string,
        assignedTo: formData.get('assignedTo') as string,
        priority: formData.get('priority') as string,
        status: formData.get('status') as string,
    };

    if (!logDetails.projectName || !logDetails.projectName.trim()) {
        alert("Project name is required.");
        return;
    }

    const newLog = {
        id: Date.now(),
        image: imagePreview,
        modelUsed: selectedModel,
        ...logDetails,
        ...analysisResult,
    };
    setLoggedDefects(prevLogs => [newLog, ...prevLogs]);
    alert(`Defect logged successfully for project: ${logDetails.projectName.trim()}`);
    resetState();
  };


  /**
   * Handles submitting user feedback on the AI's analysis.
   */
  const handleFeedbackSubmit = () => {
    if (!analysisResult || !userCorrection) {
        alert("Cannot submit feedback without a valid correction.");
        return;
    }
    const newFeedback = {
        id: `feedback-${Date.now()}`,
        timestamp: new Date().toISOString(),
        image: imagePreview,
        modelUsed: selectedModel,
        aiPrediction: analysisResult.defectType,
        userCorrection: userCorrection,
    };
    setFeedbackLogs(prevFeedback => [newFeedback, ...prevFeedback]);
    setFeedbackSubmitted(true);
  };


  /**
   * Handles the Cloud AI analysis using Gemini.
   */
  const handleAnalyzeClick = async () => {
    if (!apiKey) {
        setError("API Key not found. Please set your API key in the Settings view.");
        setCurrentView('settings');
        return;
    }
    if (!imageFile) {
      setError("Please upload an image first.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setAnalysisResult(null);
    setFeedbackSubmitted(false);

    try {
      // Initialize the Google Gemini AI client with user-provided key
      const ai = new GoogleGenAI({ apiKey: apiKey });
      const imagePart = await fileToGenerativePart(imageFile);

      // Define the expected JSON output structure for the AI model with probabilities
      const schema = {
        type: Type.OBJECT,
        properties: {
          defectType: {
            type: Type.STRING,
            description: "The specific type of construction defect identified (e.g., 'Plaster Crack', 'Paint Peeling')."
          },
          defectExplanation: {
            type: Type.STRING,
            description: "A comprehensive, expert-level explanation of the defect. It MUST include: 1) The typical context/scenario where this defect is found (e.g., 'This is common on exterior walls exposed to frequent rain and poor drainage'). 2) The underlying mechanism of the defect (e.g., 'It is caused by soluble salts migrating through the masonry'). 3) The significant risks and implications if the defect is not repaired (e.g., 'Left untreated, it indicates ongoing moisture ingress that can lead to spalling, rebar corrosion, and significant structural issues')."
          },
          severity: {
            type: Type.STRING,
            description: "The severity of the defect, classified as 'Minor', 'Moderate', 'Severe', or 'NA' for images with no defect."
          },
          probableCauses: {
            type: Type.ARRAY,
            description: "A list of likely root causes for the defect, each with an assigned probability percentage.",
            items: {
              type: Type.OBJECT,
              properties: {
                cause: { type: Type.STRING, description: "Description of a single probable cause." },
                probability: { type: Type.NUMBER, description: "The probability of this cause being the reason, as a percentage (e.g., 60 for 60%)." }
              },
              required: ["cause", "probability"]
            }
          },
          contributingFactors: {
            type: Type.STRING,
            description: "A summary of common environmental or procedural factors that contribute to this type of defect."
          },
          responsibleParty: {
            type: Type.ARRAY,
            description: "A list of trades or parties most likely responsible, each with an assigned probability percentage. The sum of probabilities should be 100.",
            items: {
              type: Type.OBJECT,
              properties: {
                party: { type: Type.STRING, description: "The name of the responsible trade or party." },
                probability: { type: Type.NUMBER, description: "The probability of this party being responsible, as a percentage (e.g., 70 for 70%)." }
              },
              required: ["party", "probability"]
            }
          },
          recommendedActions: {
              type: Type.ARRAY,
              description: "A list of recommended steps or actions to repair or remedy the defect.",
              items: { type: Type.STRING }
          }
        },
        required: ["defectType", "defectExplanation", "severity", "probableCauses", "contributingFactors", "responsibleParty", "recommendedActions"],
      };

      // Construct the prompt for the AI model
      const textPart = {
          text: `You are an expert in civil engineering and construction defect analysis. Analyze the provided image of a construction defect on a wall, ceiling, or surface. Based on the visual evidence, provide a comprehensive analysis in JSON format according to the provided schema.

          When identifying the 'defectType', you **must** select from the following specific list. It is critical that if the image shows no issues, you classify it as 'No Defect / Good Condition'.

          **Defect Classification List:**
          *   ${DEFECT_TYPES.join('\n*   ')}

          Your tasks are to:
          1.  **Detect Defect:** Identify the primary construction defect shown, using one of the names from the list above.
          2.  **Explain Defect:** Provide a comprehensive, expert-level explanation of the defect. This explanation is critical and MUST include specific details on: a) **Common Scenarios:** Where and under what conditions does this defect typically appear? (e.g., 'This type of cracking is often seen in new concrete that cured too quickly under direct sun.'). b) **Underlying Mechanism:** Briefly explain the physical or chemical process causing the defect. c) **Implications & Risks:** What are the consequences if this defect is ignored? (e.g., 'If ignored, this dampness will lead to mold growth, wood rot, and can compromise the integrity of the wall structure.').
          3.  **Grade Severity:** Classify its severity as Minor, Moderate, or Severe.
          4.  **Analyze Root Cause:** Determine the most probable causes and assign a probability percentage to each.
          5.  **List Factors:** Summarize common contributing factors for this type of issue.
          6.  **Attribute Responsibility:** Assign responsibility to the relevant trade(s) and assign a probability percentage to each. The sum of probabilities must equal 100%.
          7.  **Recommend Actions:** Provide a list of recommended repair actions.

          **Important:** If you identify the image as 'No Defect / Good Condition', provide a positive confirmation in the 'defectExplanation', set 'severity' to 'NA', provide a neutral statement for 'contributingFactors' (e.g., "Standard maintenance practices are sufficient."), and return empty arrays for 'probableCauses', 'responsibleParty', and 'recommendedActions'.`
      };

      // Send the request to the Gemini API
      const response = await ai.models.generateContent({
        model: selectedModel, // Use the selected model from state
        contents: { parts: [imagePart, textPart] },
        config: {
          responseMimeType: "application/json",
          responseSchema: schema,
        }
      });
      
      const resultJson = JSON.parse(response.text);
      setAnalysisResult(resultJson);
      setUserCorrection(resultJson.defectType); // Pre-fill correction with AI's guess

    } catch (err: any) {
      console.error(err);
      setError(`An error occurred during analysis: ${err.message}`);
      // On error, clear the image to force a re-upload
      setImageFile(null);
      setImagePreview(null);
    } finally {
      setIsLoading(false);
    }
  };

  /**
   * Handles sending a message in the chatbot view.
   */
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || isChatLoading) return;

    if (!apiKey) {
        setError("API Key not found. Please set your API key in the Settings view.");
        setCurrentView('settings');
        return;
    }

    const userMessage = chatInput.trim();
    setChatMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setChatInput('');
    setIsChatLoading(true);
    setError(null);

    try {
        let currentChat = chatInstance;
        // Initialize chat on first message
        if (!currentChat) {
            const ai = new GoogleGenAI({ apiKey });
            currentChat = ai.chats.create({
                model: selectedModel,
                config: {
                    systemInstruction: 'You are a helpful and knowledgeable Construction Expert Assistant. Answer questions related to construction defects, civil engineering principles, and project management based on the user\'s queries.',
                },
            });
            setChatInstance(currentChat);
        }

        const response = await currentChat.sendMessage({ message: userMessage });
        setChatMessages(prev => [...prev, { role: 'model', text: response.text }]);
    } catch (err: any) {
        console.error(err);
        const errorMessage = `Sorry, I encountered an error: ${err.message}`;
        setChatMessages(prev => [...prev, { role: 'model', text: errorMessage }]);
        setError(errorMessage);
    } finally {
        setIsChatLoading(false);
    }
  };

  // --- UI Rendering ---
  
  const renderLogForm = () => (
    <div className="log-form-overlay">
        <div className="log-form-content">
            <h2>Log Defect Details</h2>
            <form onSubmit={handleSaveLog}>
                <div className="form-group">
                    <label htmlFor="projectName">Project Name</label>
                    <input type="text" id="projectName" name="projectName" required />
                </div>
                <div className="form-group">
                    <label htmlFor="assignedTo">Assign To</label>
                    <input type="text" id="assignedTo" name="assignedTo" placeholder="e.g., John Doe, Masonry Team" />
                </div>
                <div className="form-group">
                    <label htmlFor="priority">Priority</label>
                    <select id="priority" name="priority" defaultValue="Medium">
                        {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
                    </select>
                </div>
                <div className="form-group">
                    <label htmlFor="status">Status</label>
                    <select id="status" name="status" defaultValue="Open">
                        {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
                    </select>
                </div>
                <div className="button-group">
                    <button type="button" className="btn btn-secondary" onClick={() => setIsLogging(false)}>Cancel</button>
                    <button type="submit" className="btn">Save Log</button>
                </div>
            </form>
        </div>
    </div>
  );

  /**
   * Renders the initial view for uploading an image.
   */
  const renderUploadView = () => (
    <>
      <div className="model-selector">
        <label htmlFor="model-select">Cloud Model Version:</label>
        <select
          id="model-select"
          value={selectedModel}
          onChange={(e) => setSelectedModel(e.target.value)}
        >
          {MODEL_VERSIONS.map(model => (
            <option key={model.id} value={model.id}>{model.name}</option>
          ))}
        </select>
      </div>

      <input
        type="file"
        id="file-upload"
        accept="image/*"
        onChange={handleFileChange}
        style={{ display: 'none' }}
      />
      <label htmlFor="file-upload" className="upload-section" role="button" aria-label="Upload defect image">
        <div className="upload-icon">📷</div>
        <p>Upload Defect Image</p>
        <span>Tap to select a photo</span>
      </label>
      <div className="upload-guidance">
        💡 Tip: For best results, ensure the defect is well-lit and in focus.
      </div>
      {imagePreview && <img src={imagePreview} alt="Defect preview" className="image-preview" />}
      <button className="btn" onClick={handleAnalyzeClick} disabled={!imageFile || isLoading}>
        Analyze Defect
      </button>
    </>
  );

  /**
   * Renders the loading indicator during analysis.
   */
  const renderLoadingView = () => (
    <div className="loading-container">
      <div className="spinner"></div>
      <p>Analyzing defect, please wait...</p>
    </div>
  );

  /**
   * Renders the feedback section in the results view.
   */
  const renderFeedbackSection = () => (
    <div className="feedback-container">
        <details>
            <summary className="feedback-header">Was this analysis correct?</summary>
            <div className="feedback-content">
                <p>Your feedback helps improve the AI. If the detected defect type is wrong, please correct it below.</p>
                <label htmlFor="correction-select">Correct Defect Type:</label>
                <select
                    id="correction-select"
                    value={userCorrection || ''}
                    onChange={(e) => setUserCorrection(e.target.value)}
                    disabled={feedbackSubmitted}
                >
                    {DEFECT_TYPES.map(type => (
                        <option key={type} value={type}>{type}</option>
                    ))}
                </select>
                <button
                    className="btn"
                    onClick={handleFeedbackSubmit}
                    disabled={feedbackSubmitted || !userCorrection}
                >
                    {feedbackSubmitted ? '✅ Thank You!' : 'Submit Feedback'}
                </button>
            </div>
        </details>
    </div>
  );

  
  /**
   * Renders the analysis results view.
   */
  const renderResultsView = () => (
    <div className="results-container">
       <img src={imagePreview!} alt="Analyzed defect" />
       
       <div className="result-card">
           <h3>Defect Type</h3>
           <p>{analysisResult.defectType}</p>
       </div>

       <div className="result-card">
            <h3>Explanation</h3>
            <p>{analysisResult.defectExplanation}</p>
        </div>

       <div className="result-card">
           <h3>Severity</h3>
           <p><span className={`severity-badge severity-${analysisResult.severity}`}>{analysisResult.severity}</span></p>
       </div>
       
       {analysisResult.probableCauses?.length > 0 && (
            <div className="result-card">
                <h3>Probable Causes</h3>
                <ul>
                    {analysisResult.probableCauses.map((item: { cause: string; probability: number }, index: number) => (
                        <li key={index}>{item.cause} <strong>({item.probability}%)</strong></li>
                    ))}
                </ul>
            </div>
       )}

        <div className="result-card">
            <h3>Contributing Factors</h3>
            <p>{analysisResult.contributingFactors}</p>
        </div>
       
       {analysisResult.responsibleParty?.length > 0 && (
            <div className="result-card">
                <h3>Responsible Party</h3>
                <ul>
                        {analysisResult.responsibleParty.map((item: { party: string; probability: number }, index: number) => (
                            <li key={index}>{item.party} <strong>({item.probability}%)</strong></li>
                        ))}
                </ul>
            </div>
        )}

        {analysisResult.recommendedActions?.length > 0 && (
            <div className="result-card">
                <h3>Recommended Actions</h3>
                <ul>
                    {analysisResult.recommendedActions.map((action: string, index: number) => (
                        <li key={index}>{action}</li>
                    ))}
                </ul>
            </div>
        )}

        {renderFeedbackSection()}

       <div className="button-group">
            <button className="btn btn-secondary" onClick={() => setIsLogging(true)}>Log Defect</button>
            <button className="btn" onClick={resetState}>Analyze Another</button>
       </div>
    </div>
  );

  // --- Project & Log Management Logic ---
  const handleFilterChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const clearFilters = () => {
    setFilters({
        projectName: '',
        defectType: '',
        severity: '',
        responsibleParty: '',
        priority: '',
        status: '',
    });
  };

  const handleProjectClick = (projectName: string) => {
    clearFilters(); // Start with a clean slate
    setFilters(prev => ({ ...prev, projectName: projectName }));
    setCurrentView('logs');
  };

  const filteredDefects = useMemo(() => {
    return loggedDefects.filter(defect => {
      const matchProject = filters.projectName ? defect.projectName.toLowerCase().includes(filters.projectName.toLowerCase()) : true;
      const matchDefectType = filters.defectType ? defect.defectType === filters.defectType : true;
      const matchSeverity = filters.severity ? defect.severity === filters.severity : true;
      const matchResponsibleParty = filters.responsibleParty ? defect.responsibleParty.some((p: any) => p.party === filters.responsibleParty) : true;
      const matchPriority = filters.priority ? defect.priority === filters.priority : true;
      const matchStatus = filters.status ? defect.status === filters.status : true;
      return matchProject && matchDefectType && matchSeverity && matchResponsibleParty && matchPriority && matchStatus;
    });
  }, [loggedDefects, filters]);

  const uniqueDefectTypes = useMemo(() => [...new Set(loggedDefects.map(d => d.defectType))], [loggedDefects]);
  const uniqueResponsibleParties = useMemo(() => [...new Set(loggedDefects.flatMap(d => d.responsibleParty?.map((p: any) => p.party) || []))], [loggedDefects]);

  const dashboardStats = useMemo(() => {
    const severities: { [key: string]: number } = { Minor: 0, Moderate: 0, Severe: 0, NA: 0 };
    const projects = new Map<string, number>();

    loggedDefects.forEach(defect => {
        if (defect.severity in severities) {
            severities[defect.severity]++;
        }
        projects.set(defect.projectName, (projects.get(defect.projectName) || 0) + 1);
    });

    const projectCounts = Array.from(projects.entries()).map(([name, count]) => ({ name, count })).sort((a,b) => b.count - a.count);

    return { total: loggedDefects.length, severities, projectCounts };
}, [loggedDefects]);

const renderDashboardView = () => {
    if (loggedDefects.length === 0) {
        return null; // Don't show the dashboard if there are no logs
    }
    return (
        <div className="dashboard-container">
            <h4>Dashboard Summary</h4>
            <div className="dashboard-grid">
                <div className="stat-card">
                    <span className="stat-card-number">{dashboardStats.total}</span>
                    <span className="stat-card-label">Total Logs</span>
                </div>
                <div className="stat-card">
                    <span className="stat-card-number severity-Minor-text">{dashboardStats.severities.Minor}</span>
                    <span className="stat-card-label">Minor</span>
                </div>
                <div className="stat-card">
                    <span className="stat-card-number severity-Moderate-text">{dashboardStats.severities.Moderate}</span>
                    <span className="stat-card-label">Moderate</span>
                </div>
                <div className="stat-card">
                    <span className="stat-card-number severity-Severe-text">{dashboardStats.severities.Severe}</span>
                    <span className="stat-card-label">Severe</span>
                </div>
            </div>
            <div className="project-summary-card">
                <h5>Defects by Project</h5>
                <ul>
                    {dashboardStats.projectCounts.map(({ name, count }) => (
                        <li key={name}>
                            <span>{name}</span>
                            <span className="project-count-badge">{count}</span>
                        </li>
                    ))}
                </ul>
            </div>
        </div>
    );
};

const renderProjectsView = () => (
    <div className="projects-view-container">
        <h2>Projects</h2>
        <div className="projects-list">
            {dashboardStats.projectCounts.length === 0 && (
                <p className="no-logs-message">No projects found. Log a defect to create a new project.</p>
            )}
            {dashboardStats.projectCounts.map(({ name, count }) => (
                <div key={name} className="project-item-card" onClick={() => handleProjectClick(name)}>
                    <div className="project-item-info">
                        <h3>{name}</h3>
                        <p>{count} {count === 1 ? 'defect' : 'defects'} logged</p>
                    </div>
                    <span className="project-item-arrow">›</span>
                </div>
            ))}
        </div>
    </div>
);


  const renderLogsView = () => (
    <div className="logs-view-container">
        {renderDashboardView()}
        <div className="filter-controls">
            <input
                type="text"
                name="projectName"
                placeholder="Filter by Project Name..."
                value={filters.projectName}
                onChange={handleFilterChange}
            />
            <select name="defectType" value={filters.defectType} onChange={handleFilterChange}>
                <option value="">All Defect Types</option>
                {uniqueDefectTypes.map(type => <option key={type} value={type}>{type}</option>)}
            </select>
            <select name="severity" value={filters.severity} onChange={handleFilterChange}>
                <option value="">All Severities</option>
                <option value="Minor">Minor</option>
                <option value="Moderate">Moderate</option>
                <option value="Severe">Severe</option>
                <option value="NA">N/A</option>
            </select>
            <select name="priority" value={filters.priority} onChange={handleFilterChange}>
                <option value="">All Priorities</option>
                {PRIORITIES.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
             <select name="status" value={filters.status} onChange={handleFilterChange}>
                <option value="">All Statuses</option>
                {STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <select name="responsibleParty" value={filters.responsibleParty} onChange={handleFilterChange}>
                <option value="">All Trades</option>
                 {uniqueResponsibleParties.map(party => <option key={party} value={party}>{party}</option>)}
            </select>
            <button className="btn-clear-filters" onClick={clearFilters}>Clear Filters</button>
        </div>
        <div className="logs-list">
            {loggedDefects.length === 0 && <p className="no-logs-message">No defects have been logged yet.</p>}
            {loggedDefects.length > 0 && filteredDefects.length === 0 && <p className="no-logs-message">No defects match the current filters.</p>}
            {filteredDefects.map(defect => (
                <div key={defect.id} className="log-item-card" onClick={() => setSelectedLog(defect)}>
                    <img src={defect.image} alt="Logged defect" className="log-item-image" />
                    <div className="log-item-details">
                        <h4>{defect.defectType}</h4>
                        <p><strong>Project:</strong> {defect.projectName}</p>
                        <div className="log-item-badges">
                            <span className={`severity-badge severity-${defect.severity}`}>{defect.severity}</span>
                            <span className={`priority-badge priority-${defect.priority}`}>{defect.priority}</span>
                            <span className={`status-badge status-${defect.status.replace(' ', '')}`}>{defect.status}</span>
                        </div>
                         <p><strong>Assigned:</strong> {defect.assignedTo || 'N/A'}</p>
                    </div>
                </div>
            ))}
        </div>
    </div>
  );

    const renderLogDetailModal = () => {
        if (!selectedLog) return null;

        return (
            <div className="modal-overlay" onClick={() => setSelectedLog(null)}>
                <div className="modal-content" onClick={e => e.stopPropagation()}>
                    <button className="modal-close-btn" onClick={() => setSelectedLog(null)}>&times;</button>
                    <h2>Defect Details</h2>
                    <div className="results-container modal-results">
                        <img src={selectedLog.image} alt="Analyzed defect" />
                        
                        <div className="result-card">
                            <h3>Project Details</h3>
                            <p><strong>Project:</strong> {selectedLog.projectName}</p>
                            <p><strong>Assigned To:</strong> {selectedLog.assignedTo || 'N/A'}</p>
                            <p><strong>Priority:</strong> <span className={`priority-badge priority-${selectedLog.priority}`}>{selectedLog.priority}</span></p>
                            <p><strong>Status:</strong> <span className={`status-badge status-${selectedLog.status.replace(' ', '')}`}>{selectedLog.status}</span></p>
                            <p><strong>AI Model:</strong> {selectedLog.modelUsed}</p>
                        </div>
                        
                        <div className="result-card">
                            <h3>Defect Type</h3>
                            <p>{selectedLog.defectType}</p>
                        </div>

                        <div className="result-card">
                            <h3>Explanation</h3>
                            <p>{selectedLog.defectExplanation}</p>
                        </div>

                        <div className="result-card">
                            <h3>Severity</h3>
                            <p><span className={`severity-badge severity-${selectedLog.severity}`}>{selectedLog.severity}</span></p>
                        </div>
                        
                        {selectedLog.probableCauses?.length > 0 && (
                            <div className="result-card">
                                <h3>Probable Causes</h3>
                                <ul>
                                    {selectedLog.probableCauses.map((item: { cause: string; probability: number }, index: number) => (
                                        <li key={index}>{item.cause} <strong>({item.probability}%)</strong></li>
                                    ))}
                                </ul>
                            </div>
                        )}

                        <div className="result-card">
                            <h3>Contributing Factors</h3>
                            <p>{selectedLog.contributingFactors}</p>
                        </div>
                        
                        {selectedLog.responsibleParty?.length > 0 && (
                            <div className="result-card">
                                <h3>Responsible Party</h3>
                                <ul>
                                    {selectedLog.responsibleParty.map((item: { party: string; probability: number }, index: number) => (
                                        <li key={index}>{item.party} <strong>({item.probability}%)</strong></li>
                                    ))}
                                </ul>
                            </div>
                        )}

                        {selectedLog.recommendedActions?.length > 0 && (
                             <div className="result-card">
                                <h3>Recommended Actions</h3>
                                <ul>
                                    {selectedLog.recommendedActions.map((action: string, index: number) => (
                                        <li key={index}>{action}</li>
                                    ))}
                                </ul>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        );
    };

    const renderReportsView = () => {
        const uniqueProjects = dashboardStats.projectCounts;
        
        if (!selectedProjectForReport) {
            return (
                <div className="reports-view-container project-selector-view">
                    <h2>Select a Project to Report On</h2>
                     <div className="projects-list">
                        {uniqueProjects.length === 0 && (
                            <p className="no-logs-message">No projects found. Log a defect to create a project.</p>
                        )}
                        {uniqueProjects.map(({ name, count }) => (
                             <div key={name} className="project-item-card" onClick={() => setSelectedProjectForReport(name)}>
                                <div className="project-item-info">
                                    <h3>{name}</h3>
                                    <p>{count} {count === 1 ? 'defect' : 'defects'} logged</p>
                                </div>
                                <span className="project-item-arrow">›</span>
                            </div>
                        ))}
                    </div>
                </div>
            );
        }

        const projectDefects = loggedDefects.filter(d => d.projectName === selectedProjectForReport);
        const totalDefects = projectDefects.length;

        // FIX: Explicitly type the accumulator in reduce to ensure correct type inference for counts.
        const severityCounts = projectDefects.reduce<Record<string, number>>((acc, d) => {
            acc[d.severity] = (acc[d.severity] || 0) + 1;
            return acc;
        }, {});

        // FIX: Explicitly type the accumulator in reduce to ensure correct type inference for counts.
        const statusCounts = projectDefects.reduce<Record<string, number>>((acc, d) => {
            acc[d.status] = (acc[d.status] || 0) + 1;
            return acc;
        }, {});

        // FIX: Explicitly type the accumulator in reduce to ensure correct type inference for counts.
        const defectTypeCounts = projectDefects.reduce<Record<string, number>>((acc, d) => {
            acc[d.defectType] = (acc[d.defectType] || 0) + 1;
            return acc;
        }, {});

        const pieColors = ['#1a73e8', '#ffc107', '#dc3545', '#28a745', '#6c757d', '#17a2b8'];
        
        const generateConicGradient = (counts: Record<string, number>) => {
            const total = Object.values(counts).reduce((sum, val) => sum + val, 0);
            if (total === 0) return 'lightgrey';
            let gradient = '';
            let currentPercentage = 0;
            Object.entries(counts).forEach(([key, value], index) => {
                const percentage = (value / total) * 100;
                gradient += `${pieColors[index % pieColors.length]} ${currentPercentage}% ${currentPercentage + percentage}%, `;
                currentPercentage += percentage;
            });
            return gradient.slice(0, -2);
        };
        
        return (
            <div className="reports-view-container">
                <div className="report-controls">
                     <button className="btn btn-secondary" onClick={() => setSelectedProjectForReport(null)}>‹ Back to Projects</button>
                     <button className="btn" onClick={() => window.print()}>🖨️ Print Report</button>
                </div>
                <div className="report-content">
                    <div className="report-header">
                        <h2>Project Report: {selectedProjectForReport}</h2>
                        <p>Generated on: {new Date().toLocaleDateString()}</p>
                    </div>

                    <div className="report-stats-grid">
                        <div className="stat-card">
                            <span className="stat-card-number">{totalDefects}</span>
                            <span className="stat-card-label">Total Defects</span>
                        </div>
                        {Object.entries(statusCounts).map(([status, count]) => (
                            <div className="stat-card" key={status}>
                                <span className="stat-card-number">{count}</span>
                                <span className="stat-card-label">{status}</span>
                            </div>
                        ))}
                    </div>

                    <div className="report-charts-grid">
                        <div className="chart-container">
                            <h3 className="chart-title">Defects by Severity</h3>
                            <div className="pie-chart-container">
                                <div className="pie-chart" style={{ background: generateConicGradient(severityCounts) }}></div>
                                <ul className="pie-legend">
                                    {Object.entries(severityCounts).map(([key, value], index) => (
                                        <li key={key}><span className="legend-dot" style={{ backgroundColor: pieColors[index % pieColors.length] }}></span>{key}: {value}</li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                         <div className="chart-container">
                            <h3 className="chart-title">Defects by Status</h3>
                            <div className="pie-chart-container">
                                <div className="pie-chart" style={{ background: generateConicGradient(statusCounts) }}></div>
                                <ul className="pie-legend">
                                    {Object.entries(statusCounts).map(([key, value], index) => (
                                        <li key={key}><span className="legend-dot" style={{ backgroundColor: pieColors[index % pieColors.length] }}></span>{key}: {value}</li>
                                    ))}
                                </ul>
                            </div>
                        </div>
                    </div>
                    
                    <div className="chart-container">
                        <h3 className="chart-title">Defect Type Breakdown</h3>
                        <div className="bar-chart-container">
                             {Object.entries(defectTypeCounts).sort(([, a], [, b]) => b - a).map(([type, count]) => (
                                <div className="bar-item" key={type}>
                                    <span className="bar-label">{type}</span>
                                    <div className="bar-wrapper">
                                        <div className="bar-fill" style={{ width: `${(count / Math.max(...Object.values(defectTypeCounts))) * 100}%` }}>
                                            <span className="bar-count">{count}</span>
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        );
    };

    const SettingsView = () => {
        const [currentKey, setCurrentKey] = useState(apiKey);
        const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
        const debounceTimeout = useRef<number | null>(null);
    
        const handleKeyChange = (newKey: string) => {
            setCurrentKey(newKey);
            setSaveStatus('saving');
    
            // Clear the previous timeout if it exists
            if (debounceTimeout.current) {
                clearTimeout(debounceTimeout.current);
            }
    
            // Set a new timeout to save the key after 500ms of inactivity
            debounceTimeout.current = window.setTimeout(() => {
                setApiKey(newKey);
                localStorage.setItem('userApiKey', newKey);
                setSaveStatus('saved');
    
                // Hide the 'saved' message after 2 seconds
                setTimeout(() => setSaveStatus('idle'), 2000);
            }, 500);
        };
    
        return (
            <div className="settings-view-container">
                <h2>API Key Settings</h2>
                <div className="api-key-warning">
                    <strong>Warning:</strong> Never expose your API key in a public application. This feature is for temporary development use only. The key is saved in your browser's local storage and is not secure.
                </div>
                <label htmlFor="api-key-input">Your Gemini API Key:</label>
                <input
                    id="api-key-input"
                    type="password"
                    value={currentKey}
                    onChange={(e) => handleKeyChange(e.target.value)}
                    placeholder="Enter your API Key here"
                />
                 <div className="save-confirmation">
                    {saveStatus === 'saving' && 'Saving...'}
                    {saveStatus === 'saved' && '✅ Saved automatically'}
                </div>
            </div>
        );
    };

    const renderChatView = () => (
        <div className="chat-view-container">
            <div className="chat-messages-container">
                {chatMessages.length === 0 && <p className="no-logs-message">Ask the Construction Expert Assistant anything!</p>}
                {chatMessages.map((msg, index) => (
                    <div key={index} className={`chat-message ${msg.role}-message`}>
                        <p>{msg.text}</p>
                    </div>
                ))}
                {isChatLoading && (
                    <div className="chat-message model-message">
                        <div className="typing-indicator">
                            <span></span><span></span><span></span>
                        </div>
                    </div>
                )}
            </div>
            <form className="chat-input-form" onSubmit={handleSendMessage}>
                <input
                    type="text"
                    className="chat-input"
                    value={chatInput}
                    onChange={(e) => setChatInput(e.target.value)}
                    placeholder="Ask about defects, repairs..."
                    disabled={isChatLoading}
                />
                <button type="submit" className="send-btn" disabled={isChatLoading || !chatInput.trim()}>
                    ➤
                </button>
            </form>
        </div>
    );


  return (
    <div className="app-container">
      <header className="app-header">
        <h1>ConstructDefect AI</h1>
        <nav className="view-toggle">
            <button className={currentView === 'analyzer' ? 'active' : ''} onClick={() => setCurrentView('analyzer')}>Analyzer</button>
            <button className={currentView === 'chat' ? 'active' : ''} onClick={() => setCurrentView('chat')}>Chat</button>
            <button className={currentView === 'projects' ? 'active' : ''} onClick={() => setCurrentView('projects')}>Projects</button>
            <button className={currentView === 'logs' ? 'active' : ''} onClick={() => setCurrentView('logs')}>Logs</button>
            <button className={currentView === 'reports' ? 'active' : ''} onClick={() => { setCurrentView('reports'); setSelectedProjectForReport(null);}}>Reports</button>
            <button className={currentView === 'settings' ? 'active' : ''} onClick={() => setCurrentView('settings')}>Settings</button>
        </nav>
      </header>
      <main className="app-main">
        {currentView === 'analyzer' && (
             <>
                {!isLoading && !analysisResult && renderUploadView()}
                {isLoading && renderLoadingView()}
                {!isLoading && analysisResult && renderResultsView()}
                {error && <p className="error-message">{error}</p>}
            </>
        )}
        {currentView === 'chat' && renderChatView()}
        {currentView === 'projects' && renderProjectsView()}
        {currentView === 'logs' && renderLogsView()}
        {currentView === 'reports' && renderReportsView()}
        {currentView === 'settings' && <SettingsView />}
      </main>
      {isLogging && renderLogForm()}
      {renderLogDetailModal()}
    </div>
  );
};


const container = document.getElementById('root');
const root = createRoot(container!);
root.render(<App />);